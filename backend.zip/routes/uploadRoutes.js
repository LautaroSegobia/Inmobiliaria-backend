
import express from "express";
import upload from "../middleware/uploadMiddleware.js";
import { protect, adminOrDeveloperOnly } from "../middleware/authmiddleware.js";
import { uploadFiles, deleteFile } from "../controllers/uploadController.js";

const router = express.Router();

// Subir archivos (solo admin o developer)
router.post("/", protect, adminOrDeveloperOnly, upload.array("images", 20), uploadFiles);

// Eliminar archivo de Cloudinary
router.delete("/:public_id", protect, adminOrDeveloperOnly, deleteFile);

export default router;
